/* KrishiConnect login page: background slideshow, language switcher, login / register with the API */
const $ = id => document.getElementById(id);
let mode = "login", role = "Farmer", lang = "en";

/* ---------- Background slideshow ----------
   Illustrated farm scenes are in images/scene1-6.svg.
   To use real photos too, drop farm1.jpg ... farm6.jpg into the images folder.
   Missing files are skipped automatically. */
const bgImages = [
  "images/scene1.svg", "images/scene2.svg", "images/scene3.svg",
  "images/scene4.svg", "images/scene5.svg", "images/scene6.svg",
  "images/farm1.jpg", "images/farm2.jpg", "images/farm3.jpg",
  "images/farm4.jpg", "images/farm5.jpg", "images/farm6.jpg"
];
const slidesBox = $("slides");
const slides = [];
let current = 0;

bgImages.forEach(src => {
  const im = new Image();
  im.onload = () => {
    const d = document.createElement("div");
    d.className = "slide";
    d.style.backgroundImage = `url("${src}")`;
    slidesBox.appendChild(d);
    slides.push(d);
    if (slides.length === 1) d.classList.add("on");
  };
  im.src = src;
});
setInterval(() => {
  if (slides.length < 2) return;
  slides[current].classList.remove("on");
  current = (current + 1) % slides.length;
  slides[current].classList.add("on");
}, 6500);

/* ---------- Language ---------- */
const t = key => (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    if (el.hasAttribute("data-html")) el.innerHTML = t(el.dataset.i18n);
    else el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-ph]").forEach(el => el.placeholder = t(el.dataset.i18nPh));
  renderMode();
}

function renderMode() {
  const reg = mode === "register";
  $("title").textContent = t(reg ? "titleReg" : "titleLogin");
  $("sub").textContent = t(reg ? "subReg" : "subLogin");
  if (!$("submit").disabled) $("submit").textContent = t(reg ? "btnReg" : "btnLogin");
}

$("lang").addEventListener("change", e => {
  lang = e.target.value;
  try { localStorage.setItem("krishi_lang", lang); } catch (_) {}
  applyLang();
});

/* ---------- UI helpers ---------- */
function toast(text, ms = 3600) {
  const el = $("toast");
  el.textContent = text;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), ms);
}

document.querySelectorAll(".tab").forEach(b => b.onclick = () => {
  mode = b.dataset.mode;
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === b));
  const reg = mode === "register";
  $("fName").classList.toggle("hide", !reg);
  $("fPhone").classList.toggle("hide", !reg);
  $("rowLogin").classList.toggle("hide", reg);
  $("pass").autocomplete = reg ? "new-password" : "current-password";
  document.querySelectorAll(".field").forEach(f => f.classList.remove("err"));
  renderMode();
});

document.querySelectorAll(".role").forEach(r => r.onclick = () => {
  document.querySelectorAll(".role").forEach(x => x.classList.remove("sel"));
  r.classList.add("sel");
  role = r.dataset.r;
});

$("eye").onclick = () => {
  const p = $("pass"), show = p.type === "password";
  p.type = show ? "text" : "password";
  $("eye").textContent = show ? "🙈" : "👁️";
};
$("forgot").onclick = e => { e.preventDefault(); toast(t("toastForgot")); };
document.querySelectorAll(".alt button").forEach(b => b.onclick = () => toast(b.dataset.p + ": " + t("toastSocial")));

/* ---------- Talking to the backend ---------- */
const roleName = r => t("role" + r.charAt(0).toUpperCase() + r.slice(1));     // "farmer" -> translated "Farmer"

function errorText(err) {
  const d = err && err.detail;
  switch (d && d.code) {
    case "invalid_credentials":   return t("errInvalid");
    case "already_registered":    return t("errTaken");
    case "role_mismatch":         return t("errRoleMismatch").replace("{role}", roleName(d.role));
    case "account_locked":        return t("errLocked");
    case "admin_signup_blocked":  return t("errAdminBlocked");
    case undefined:               return t("errNetwork");          // no answer from the server
    default:                      return t("errGeneric");
  }
}

async function callApi(path, payload) {
  let res;
  try {
    res = await fetch(API_BASE + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } catch (_) {
    throw { detail: undefined };                                   // server not running / not reachable
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, detail: data.detail || { code: "unknown" } };
  return data;
}

/* ---------- Form ---------- */
function bad(id, cond) { $(id).closest(".field").classList.toggle("err", cond); return cond; }

$("form").addEventListener("submit", async e => {
  e.preventDefault();
  let invalid = false;
  if (mode === "register") {
    invalid = bad("name", $("name").value.trim().length < 2) || invalid;
    invalid = bad("phone", !/^[6-9]\d{9}$/.test($("phone").value)) || invalid;
  }
  invalid = bad("email", !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($("email").value)) || invalid;
  invalid = bad("pass", $("pass").value.length < 8) || invalid;
  if (invalid) return;

  const btn = $("submit");
  btn.disabled = true;
  btn.textContent = t("toastWait");

  const base = { email: $("email").value.trim(), password: $("pass").value, role: role.toLowerCase() };
  const payload = mode === "register"
    ? { ...base, name: $("name").value.trim(), phone: $("phone").value, language: lang }
    : base;

  try {
    const data = await callApi("/api/auth/" + mode, payload);
    Session.save(data, $("remember").checked);
    toast(t(mode === "login" ? "toastLogin" : "toastReg").replace("{role}", roleName(data.user.role)), 1500);
    setTimeout(() => { location.href = "dashboard.html"; }, 900);     // button stays disabled while we leave
  } catch (err) {
    toast(errorText(err), 4500);
    btn.disabled = false;
    renderMode();
  }
});

/* ---------- Init ---------- */
try { lang = localStorage.getItem("krishi_lang") || "en"; } catch (_) {}
if (!I18N[lang]) lang = "en";
$("lang").value = lang;
applyLang();
