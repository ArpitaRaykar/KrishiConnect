/* KrishiConnect dashboard: shows the logged-in user. Anyone without a valid token is sent back to the login page. */
const $ = id => document.getElementById(id);
let lang = "en", user = null;
const t = key => (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
const roleName = r => t("role" + r.charAt(0).toUpperCase() + r.slice(1));

function toast(text) {
  const el = $("toast");
  el.textContent = text;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 4500);
}

function render() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => el.textContent = t(el.dataset.i18n));
  if (!user) return;
  $("welcome").textContent = t("dashWelcome").replace("{name}", user.name.split(" ")[0]);
  $("roleBadge").textContent = roleName(user.role);
  $("uRole").textContent = roleName(user.role);
  $("uEmail").textContent = user.email;
  $("uPhone").textContent = user.phone;
  $("avatar").textContent = user.name.trim().charAt(0).toUpperCase();
}

function toLogin() { Session.clear(); location.replace("index.html"); }

async function init() {
  try { lang = localStorage.getItem("krishi_lang") || ""; } catch (_) {}

  const token = Session.token();
  if (!token) return toLogin();

  let res;
  try {
    res = await fetch(API_BASE + "/api/auth/me", { headers: { Authorization: "Bearer " + token } });
  } catch (_) {
    lang = I18N[lang] ? lang : "en";
    $("lang").value = lang; render();
    return toast(t("errNetwork"));
  }
  if (res.status === 401) return toLogin();                       // expired or invalid token
  if (!res.ok) { lang = I18N[lang] ? lang : "en"; $("lang").value = lang; render(); return toast(t("errGeneric")); }

  user = await res.json();
  if (!I18N[lang]) lang = user.preferred_language;                // first visit: use the language chosen at sign-up
  if (!I18N[lang]) lang = "en";
  $("lang").value = lang;
  $("card").hidden = false;
  $("mods").hidden = false;
  render();
}

$("lang").addEventListener("change", e => {
  lang = e.target.value;
  try { localStorage.setItem("krishi_lang", lang); } catch (_) {}
  render();
});
$("logout").addEventListener("click", toLogin);

init();
