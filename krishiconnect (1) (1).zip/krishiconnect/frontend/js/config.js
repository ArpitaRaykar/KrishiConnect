/* Where the backend API lives.
   - Opened from the backend itself (http://127.0.0.1:8000) -> same address, nothing to set.
   - Opened with VS Code Live Server (port 5500) or any other port -> the API is on port 8000.
   To use a deployed server, set window.KRISHI_API_BASE = "https://your-domain.com" before this file loads. */
const API_BASE = window.KRISHI_API_BASE ??
  ((location.port === "8000" || (location.port === "" && location.protocol !== "file:")) ? "" : "http://127.0.0.1:8000");

/* The login token is kept in localStorage when "Remember me" is ticked, otherwise in sessionStorage. */
const Session = {
  save(data, remember) {
    this.clear();
    const store = remember ? localStorage : sessionStorage;
    try {
      store.setItem("krishi_token", data.access_token);
      store.setItem("krishi_user", JSON.stringify(data.user));
    } catch (_) {}
  },
  token() {
    try { return localStorage.getItem("krishi_token") || sessionStorage.getItem("krishi_token"); } catch (_) { return null; }
  },
  clear() {
    for (const s of [localStorage, sessionStorage]) {
      try { s.removeItem("krishi_token"); s.removeItem("krishi_user"); } catch (_) {}
    }
  }
};
