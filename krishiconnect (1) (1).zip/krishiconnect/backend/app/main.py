"""KrishiConnect API.   Run from the backend folder:   uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import db
from .config import CORS_ORIGINS, FRONTEND_DIR
from .errors import ApiError
from .routes import admin, auth


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.pool.open(wait=True, timeout=15)       # fails with a clear message if PostgreSQL is not running
    db.init_schema()                          # creates the tables on first run
    yield
    db.pool.close()


app = FastAPI(title="KrishiConnect API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    return response


@app.exception_handler(ApiError)
async def api_error_handler(_: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status, content={"detail": exc.body})


@app.exception_handler(RequestValidationError)
async def validation_handler(_: Request, exc: RequestValidationError):
    fields = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
    return JSONResponse(status_code=422, content={
        "detail": {"code": "validation_error", "message": "Some fields are invalid.", "fields": fields}})


@app.get("/api/health", tags=["system"])
def health():
    ok = db.ping()
    return JSONResponse(status_code=200 if ok else 503, content={"status": "ok" if ok else "error",
                                                                 "database": "up" if ok else "down"})


app.include_router(auth.router)
app.include_router(admin.router)

# Serve the web pages from the same address, so http://127.0.0.1:8000 opens the login page.
if FRONTEND_DIR.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
