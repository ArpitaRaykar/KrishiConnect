"""PostgreSQL connection pool (psycopg 3). All queries in this project use parameters, never string joining."""
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from .config import DATABASE_URL, SCHEMA_FILE

pool = ConnectionPool(
    conninfo=DATABASE_URL,
    min_size=1,
    max_size=10,
    kwargs={"row_factory": dict_row},   # rows come back as dictionaries
    open=False,                          # opened in main.py on startup
)


def init_schema() -> None:
    """Create the tables if they do not exist yet."""
    sql = SCHEMA_FILE.read_text(encoding="utf-8")
    with pool.connection() as conn:
        conn.execute(sql)


def ping() -> bool:
    try:
        with pool.connection() as conn:
            conn.execute("SELECT 1")
        return True
    except Exception:
        return False
