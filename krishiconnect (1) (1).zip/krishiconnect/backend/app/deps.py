"""Reusable checks for protected endpoints."""
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .db import pool
from .errors import ApiError
from .security import decode_access_token

_bearer = HTTPBearer(auto_error=False)

USER_COLUMNS = "id, name, email, phone, role, preferred_language, created_at"


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> dict:
    """Read the 'Authorization: Bearer <token>' header and return the logged-in user."""
    if creds is None:
        raise ApiError(401, "not_authenticated", "Please log in.")
    payload = decode_access_token(creds.credentials)
    if payload is None:
        raise ApiError(401, "invalid_token", "Your session has expired. Please log in again.")
    with pool.connection() as conn:
        user = conn.execute(
            f"SELECT {USER_COLUMNS} FROM users WHERE id = %s AND is_active", (payload["sub"],)
        ).fetchone()
    if user is None:
        raise ApiError(401, "invalid_token", "Your session has expired. Please log in again.")
    return user


def require_role(*roles: str):
    """Use as Depends(require_role('admin')) to allow only some roles. The check is done on the server,
    so changing the page in the browser can never give someone extra rights."""
    def checker(user: dict = Depends(current_user)) -> dict:
        if user["role"] not in roles:
            raise ApiError(403, "forbidden", "You do not have permission for this action.")
        return user
    return checker
