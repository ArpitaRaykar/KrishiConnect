"""Settings read from environment variables (or the .env file next to the backend folder)."""
import logging
import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent          # .../backend
load_dotenv(BASE_DIR / ".env")

log = logging.getLogger("krishiconnect")

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://krishi:krishi123@localhost:5432/krishiconnect")

# Used to sign login tokens. Set a long random value in .env for real use.
_secret = os.getenv("JWT_SECRET", "").strip()
if len(_secret) < 32 or _secret.startswith("change-me"):
    _secret = secrets.token_urlsafe(48)
    log.warning("JWT_SECRET is missing or too short, using a temporary one. "
                "Everyone will be logged out whenever the server restarts. Set JWT_SECRET in backend/.env")
JWT_SECRET = _secret
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "60"))

# Account lock after repeated wrong passwords
MAX_FAILED_ATTEMPTS = int(os.getenv("MAX_FAILED_ATTEMPTS", "5"))
LOCK_MINUTES = int(os.getenv("LOCK_MINUTES", "15"))

# Pages allowed to call the API from a browser (comma separated)
CORS_ORIGINS = [o.strip() for o in os.getenv(
    "CORS_ORIGINS",
    "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:8000,http://localhost:8000",
).split(",") if o.strip()]

FRONTEND_DIR = Path(os.getenv("FRONTEND_DIR", BASE_DIR.parent / "frontend"))
SCHEMA_FILE = BASE_DIR / "sql" / "schema.sql"
