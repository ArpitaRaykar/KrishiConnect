"""Create an administrator account directly in PostgreSQL.

    python -m app.create_admin
"""
import getpass
import re
import sys

from psycopg import errors as pg_errors

from . import db
from .security import hash_password


def main() -> int:
    print("Create a KrishiConnect administrator\n")
    name = input("Full name: ").strip()
    email = input("Email: ").strip().lower()
    phone = input("Mobile (10 digits): ").strip()
    password = getpass.getpass("Password (min 8 characters): ")
    again = getpass.getpass("Repeat password: ")

    if len(name) < 2:
        return _fail("Name is too short.")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        return _fail("Email is not valid.")
    if not re.fullmatch(r"[6-9][0-9]{9}", phone):
        return _fail("Mobile must be 10 digits starting with 6, 7, 8 or 9.")
    if len(password) < 8 or len(password.encode()) > 72:
        return _fail("Password must be 8 to 72 characters.")
    if password != again:
        return _fail("Passwords do not match.")

    db.pool.open(wait=True, timeout=15)
    try:
        db.init_schema()
        with db.pool.connection() as conn:
            conn.execute(
                "INSERT INTO users (name, email, phone, password_hash, role) VALUES (%s, %s, %s, %s, 'admin')",
                (name, email, phone, hash_password(password)),
            )
    except pg_errors.UniqueViolation:
        return _fail("An account with this email or mobile already exists.")
    finally:
        db.pool.close()

    print(f"\nAdmin created. Log in with {email} and choose the Admin role.")
    return 0


def _fail(msg: str) -> int:
    print("Error:", msg)
    return 1


if __name__ == "__main__":
    sys.exit(main())
