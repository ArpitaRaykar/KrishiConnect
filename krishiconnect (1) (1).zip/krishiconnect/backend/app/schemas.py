"""Request and response shapes. Pydantic checks every field before our code runs."""
from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator

Role = Literal["farmer", "buyer", "seller", "admin"]
Language = Literal["en", "kn", "hi", "te", "ta", "mr"]


def _password_ok(value: str) -> str:
    if len(value.encode("utf-8")) > 72:
        raise ValueError("Password must be at most 72 bytes")
    return value


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(pattern=r"^[6-9][0-9]{9}$")        # Indian mobile: 10 digits starting 6-9
    password: str = Field(min_length=8, max_length=72)
    role: Role
    language: Language = "en"

    @field_validator("name")
    @classmethod
    def clean_name(cls, v: str) -> str:
        v = " ".join(v.split())
        if len(v) < 2:
            raise ValueError("Name is too short")
        return v

    @field_validator("password")
    @classmethod
    def password_bytes(cls, v: str) -> str:
        return _password_ok(v)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
    role: Role


class UserOut(BaseModel):
    id: UUID
    name: str
    email: str
    phone: str
    role: Role
    preferred_language: Language
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserOut
