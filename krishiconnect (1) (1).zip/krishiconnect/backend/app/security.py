"""Password hashing (bcrypt) and login tokens (JWT)."""
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .config import ACCESS_TOKEN_MINUTES, JWT_ALGORITHM, JWT_SECRET

BCRYPT_MAX_BYTES = 72   # bcrypt ignores everything after 72 bytes, so we reject longer passwords


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("ascii")


def verify_password(password: str, password_hash: str) -> bool:
    raw = password.encode("utf-8")
    if len(raw) > BCRYPT_MAX_BYTES:
        return False
    try:
        return bcrypt.checkpw(raw, password_hash.encode("ascii"))
    except ValueError:
        return False


# Checked when the email does not exist, so a missing account takes as long as a wrong password.
# This stops people from discovering which emails are registered by measuring response time.
DUMMY_HASH = hash_password("not-a-real-password")


def create_access_token(user_id: str, role: str) -> tuple[str, int]:
    """Return (token, seconds until it expires)."""
    expires = timedelta(minutes=ACCESS_TOKEN_MINUTES)
    now = datetime.now(timezone.utc)
    payload = {"sub": user_id, "role": role, "iat": now, "exp": now + expires}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM), int(expires.total_seconds())


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError:
        return None
