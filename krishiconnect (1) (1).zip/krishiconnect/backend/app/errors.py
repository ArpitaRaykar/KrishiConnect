"""One error format for the whole API: {"detail": {"code": "...", "message": "..."}}.
The web page translates the short `code` into the language chosen by the user."""


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, **extra):
        super().__init__(message)
        self.status = status
        self.body = {"code": code, "message": message, **extra}
