"""Admin-only example that proves role-based access works on the server."""
from fastapi import APIRouter, Depends

from ..db import pool
from ..deps import USER_COLUMNS, require_role
from ..schemas import UserOut

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/users", response_model=list[UserOut])
def list_users(limit: int = 100, _admin: dict = Depends(require_role("admin"))):
    limit = max(1, min(limit, 500))
    with pool.connection() as conn:
        return conn.execute(
            f"SELECT {USER_COLUMNS} FROM users ORDER BY created_at DESC LIMIT %s", (limit,)
        ).fetchall()
