"""Register, login and 'who am I' endpoints."""
from fastapi import APIRouter, Depends
from psycopg import errors as pg_errors

from ..config import LOCK_MINUTES, MAX_FAILED_ATTEMPTS
from ..db import pool
from ..deps import USER_COLUMNS, current_user
from ..errors import ApiError
from ..schemas import LoginIn, RegisterIn, TokenOut, UserOut
from ..security import DUMMY_HASH, create_access_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _token_response(user: dict) -> dict:
    token, expires_in = create_access_token(str(user["id"]), user["role"])
    return {"access_token": token, "token_type": "bearer", "expires_in": expires_in, "user": user}


@router.post("/register", response_model=TokenOut, status_code=201)
def register(body: RegisterIn):
    # Anyone can open the public form, so the Admin role can never be chosen here.
    # Create admins on the server with:  python -m app.create_admin
    if body.role == "admin":
        raise ApiError(403, "admin_signup_blocked", "Admin accounts cannot be created from the public form.")

    password_hash = hash_password(body.password)
    try:
        with pool.connection() as conn:
            user = conn.execute(
                f"""INSERT INTO users (name, email, phone, password_hash, role, preferred_language)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    RETURNING {USER_COLUMNS}""",
                (body.name, body.email.lower(), body.phone, password_hash, body.role, body.language),
            ).fetchone()
    except pg_errors.UniqueViolation:
        # The database itself enforces unique email and phone, so two people registering at the
        # same moment cannot create duplicates.
        raise ApiError(409, "already_registered", "An account with this email or mobile number already exists.")
    return _token_response(user)


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn):
    email = body.email.lower()
    failure: ApiError | None = None
    user = None

    # Everything happens in one transaction that is committed before any error is raised,
    # otherwise the failed-attempt counter would be rolled back together with the error.
    with pool.connection() as conn:
        row = conn.execute(
            """SELECT *, (locked_until IS NOT NULL AND locked_until > now()) AS is_locked
               FROM users WHERE lower(email) = %s""",
            (email,),
        ).fetchone()

        if row is None:
            verify_password(body.password, DUMMY_HASH)        # same time as a real check
            failure = ApiError(401, "invalid_credentials", "Invalid email or password.")

        elif row["is_locked"]:
            failure = ApiError(423, "account_locked",
                               f"Too many failed attempts. Try again in {LOCK_MINUTES} minutes.")

        else:
            if row["locked_until"] is not None:               # an old lock has expired: start fresh
                conn.execute("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = %s",
                             (row["id"],))

            if not verify_password(body.password, row["password_hash"]):
                conn.execute(
                    """UPDATE users
                       SET failed_attempts = failed_attempts + 1,
                           locked_until = CASE WHEN failed_attempts + 1 >= %s
                                               THEN now() + make_interval(mins => %s)
                                               ELSE locked_until END
                       WHERE id = %s""",
                    (MAX_FAILED_ATTEMPTS, LOCK_MINUTES, row["id"]),
                )
                failure = ApiError(401, "invalid_credentials", "Invalid email or password.")
            else:
                conn.execute(
                    "UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = now() WHERE id = %s",
                    (row["id"],),
                )
                if not row["is_active"]:
                    failure = ApiError(403, "account_disabled", "This account has been disabled.")
                elif row["role"] != body.role:
                    failure = ApiError(403, "role_mismatch",
                                       f"This account is registered as {row['role']}.", role=row["role"])
                else:
                    user = {k: row[k] for k in
                            ("id", "name", "email", "phone", "role", "preferred_language", "created_at")}

    if failure:
        raise failure
    return _token_response(user)


@router.get("/me", response_model=UserOut)
def me(user: dict = Depends(current_user)):
    """Returns the logged-in user. The dashboard page calls this to check that the token is valid."""
    return user
