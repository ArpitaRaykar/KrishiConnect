-- Run once as the PostgreSQL superuser (postgres), for example in pgAdmin's Query Tool
-- or:  psql -U postgres -f sql/setup_database.sql
-- Change the password below, and use the same one in backend/.env

CREATE USER krishi WITH PASSWORD 'krishi123';
CREATE DATABASE krishiconnect OWNER krishi;
-- The tables are created automatically when the API starts (see sql/schema.sql).
