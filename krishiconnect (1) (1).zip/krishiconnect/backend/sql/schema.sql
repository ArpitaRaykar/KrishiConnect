-- KrishiConnect database schema (PostgreSQL 13 or newer).
-- Safe to run many times: the API runs this file automatically on startup.

CREATE TABLE IF NOT EXISTS users (
    id                 UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    name               VARCHAR(100) NOT NULL,
    email              VARCHAR(254) NOT NULL,
    phone              VARCHAR(10)  NOT NULL,
    password_hash      TEXT         NOT NULL,           -- bcrypt hash, never the plain password
    role               VARCHAR(10)  NOT NULL
                       CHECK (role IN ('farmer', 'buyer', 'seller', 'admin')),
    preferred_language VARCHAR(2)   NOT NULL DEFAULT 'en'
                       CHECK (preferred_language IN ('en', 'kn', 'hi', 'te', 'ta', 'mr')),
    is_active          BOOLEAN      NOT NULL DEFAULT TRUE,
    failed_attempts    INTEGER      NOT NULL DEFAULT 0,  -- wrong passwords in a row
    locked_until       TIMESTAMPTZ,                      -- set after too many wrong passwords
    last_login_at      TIMESTAMPTZ,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- Email is compared in lower case so Ramesh@Gmail.com and ramesh@gmail.com are the same account.
CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_uq ON users (lower(email));
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_uq       ON users (phone);
CREATE INDEX        IF NOT EXISTS users_role_idx       ON users (role);
