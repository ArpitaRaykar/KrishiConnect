"""Tests run against a real PostgreSQL database. Point TEST_DATABASE_URL at a throw-away database,
for example:  postgresql://krishi:krishi123@localhost:5432/krishiconnect_test
"""
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["DATABASE_URL"] = os.environ.get(
    "TEST_DATABASE_URL", "postgresql://krishi:krishi123@localhost:5432/krishiconnect_test")
os.environ["JWT_SECRET"] = "pytest-secret-pytest-secret-pytest-secret-1234"

from fastapi.testclient import TestClient  # noqa: E402

from app import db  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:        # starts the app: opens the pool and creates the tables
        yield c


@pytest.fixture(autouse=True)
def empty_users_table(client):
    with db.pool.connection() as conn:
        conn.execute("TRUNCATE users")
    yield


@pytest.fixture
def farmer():
    return {"name": "Ramesh Gowda", "email": "ramesh@gmail.com", "phone": "9876543210",
            "password": "Harvest2026", "role": "farmer", "language": "kn"}


@pytest.fixture
def registered(client, farmer):
    r = client.post("/api/auth/register", json=farmer)
    assert r.status_code == 201
    return r.json()
