from app import db
from app.security import hash_password


def login(client, email="ramesh@gmail.com", password="Harvest2026", role="farmer"):
    return client.post("/api/auth/login", json={"email": email, "password": password, "role": role})


def code(response):
    return response.json()["detail"]["code"]


# ---------- health ----------
def test_health_reports_database_up(client):
    r = client.get("/api/health")
    assert r.status_code == 200 and r.json() == {"status": "ok", "database": "up"}


# ---------- register ----------
def test_register_returns_token_and_user_without_password(client, farmer):
    r = client.post("/api/auth/register", json=farmer)
    assert r.status_code == 201
    body = r.json()
    assert body["token_type"] == "bearer" and body["access_token"]
    assert body["user"]["email"] == "ramesh@gmail.com"
    assert body["user"]["role"] == "farmer" and body["user"]["preferred_language"] == "kn"
    assert "password" not in body["user"] and "password_hash" not in body["user"]


def test_password_is_stored_as_bcrypt_hash(client, farmer):
    client.post("/api/auth/register", json=farmer)
    with db.pool.connection() as conn:
        stored = conn.execute("SELECT password_hash FROM users").fetchone()["password_hash"]
    assert stored.startswith("$2b$") and farmer["password"] not in stored


def test_duplicate_email_is_rejected_ignoring_case(client, farmer, registered):
    again = {**farmer, "email": "RAMESH@Gmail.com", "phone": "9123456780"}
    r = client.post("/api/auth/register", json=again)
    assert r.status_code == 409 and code(r) == "already_registered"


def test_duplicate_phone_is_rejected(client, farmer, registered):
    r = client.post("/api/auth/register", json={**farmer, "email": "other@gmail.com"})
    assert r.status_code == 409 and code(r) == "already_registered"


def test_weak_password_and_bad_phone_are_rejected(client, farmer):
    assert client.post("/api/auth/register", json={**farmer, "password": "short"}).status_code == 422
    assert client.post("/api/auth/register", json={**farmer, "phone": "1234567890"}).status_code == 422
    assert client.post("/api/auth/register", json={**farmer, "email": "not-an-email"}).status_code == 422
    assert client.post("/api/auth/register", json={**farmer, "password": "x" * 80}).status_code == 422


def test_public_form_cannot_create_admin(client, farmer):
    r = client.post("/api/auth/register", json={**farmer, "role": "admin"})
    assert r.status_code == 403 and code(r) == "admin_signup_blocked"
    with db.pool.connection() as conn:
        assert conn.execute("SELECT count(*) AS n FROM users").fetchone()["n"] == 0


def test_sql_injection_text_is_just_text(client, farmer):
    r = client.post("/api/auth/register", json={**farmer, "name": "Robert'); DROP TABLE users;--"})
    assert r.status_code == 201
    assert login(client).status_code == 200      # table still exists and works


# ---------- login ----------
def test_login_success(client, registered):
    r = login(client)
    assert r.status_code == 200 and r.json()["user"]["name"] == "Ramesh Gowda"


def test_login_email_is_case_insensitive(client, registered):
    assert login(client, email="Ramesh@GMAIL.com").status_code == 200


def test_wrong_password_and_unknown_email_look_the_same(client, registered):
    wrong = login(client, password="WrongPass123")
    unknown = login(client, email="nobody@gmail.com")
    assert wrong.status_code == unknown.status_code == 401
    assert wrong.json() == unknown.json()


def test_role_mismatch_tells_the_real_role(client, registered):
    r = login(client, role="buyer")
    assert r.status_code == 403 and code(r) == "role_mismatch" and r.json()["detail"]["role"] == "farmer"


def test_account_locks_after_five_wrong_passwords_then_unlocks(client, registered):
    for _ in range(5):
        assert login(client, password="WrongPass123").status_code == 401
    locked = login(client)                                   # even the correct password is refused now
    assert locked.status_code == 423 and code(locked) == "account_locked"

    with db.pool.connection() as conn:                       # pretend the 15 minutes have passed
        conn.execute("UPDATE users SET locked_until = now() - interval '1 minute'")
    assert login(client).status_code == 200
    with db.pool.connection() as conn:
        row = conn.execute("SELECT failed_attempts, locked_until FROM users").fetchone()
    assert row["failed_attempts"] == 0 and row["locked_until"] is None


def test_correct_login_resets_failed_counter(client, registered):
    for _ in range(3):
        login(client, password="WrongPass123")
    assert login(client).status_code == 200
    for _ in range(4):
        assert login(client, password="WrongPass123").status_code == 401   # not locked: counter restarted


# ---------- token and protected routes ----------
def test_me_requires_a_valid_token(client, registered):
    token = registered["access_token"]
    ok = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert ok.status_code == 200 and ok.json()["email"] == "ramesh@gmail.com"
    assert client.get("/api/auth/me").status_code == 401
    bad = client.get("/api/auth/me", headers={"Authorization": "Bearer abc.def.ghi"})
    assert bad.status_code == 401 and code(bad) == "invalid_token"


def test_token_for_deleted_user_is_rejected(client, registered):
    with db.pool.connection() as conn:
        conn.execute("DELETE FROM users")
    r = client.get("/api/auth/me", headers={"Authorization": f"Bearer {registered['access_token']}"})
    assert r.status_code == 401


# ---------- role based access ----------
def test_only_admin_can_list_users(client, registered):
    farmer_headers = {"Authorization": f"Bearer {registered['access_token']}"}
    assert client.get("/api/admin/users", headers=farmer_headers).status_code == 403
    assert client.get("/api/admin/users").status_code == 401

    with db.pool.connection() as conn:
        conn.execute(
            "INSERT INTO users (name,email,phone,password_hash,role) VALUES (%s,%s,%s,%s,'admin')",
            ("Admin One", "admin@gmail.com", "9000000001", hash_password("AdminPass2026")))
    token = login(client, email="admin@gmail.com", password="AdminPass2026", role="admin").json()["access_token"]
    r = client.get("/api/admin/users", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200 and {u["role"] for u in r.json()} == {"farmer", "admin"}
    assert all("password_hash" not in u for u in r.json())
