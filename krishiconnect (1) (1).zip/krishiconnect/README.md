# KrishiConnect: Login, Registration and PostgreSQL Backend

Login and registration for KrishiConnect (PRJ-19). The web pages talk to a **FastAPI** server that stores users in **PostgreSQL** and signs people in with **JWT** tokens.

```
krishiconnect/
├── frontend/                 Web pages (HTML, CSS, JS) - six languages
│   ├── index.html            Login / Register
│   ├── dashboard.html        Page shown after login (needs a valid token)
│   ├── css/  js/  images/
├── backend/
│   ├── app/                  FastAPI code
│   │   ├── main.py           App start, CORS, error format, serves the frontend
│   │   ├── config.py         Settings from .env
│   │   ├── db.py             PostgreSQL connection pool
│   │   ├── security.py       bcrypt password hashing + JWT
│   │   ├── schemas.py        Input validation
│   │   ├── deps.py           "Who is logged in?" and role checks
│   │   ├── routes/auth.py    register, login, me
│   │   ├── routes/admin.py   admin-only example
│   │   └── create_admin.py   Create an admin from the terminal
│   ├── sql/schema.sql        The users table
│   ├── sql/setup_database.sql   Creates the database and user
│   ├── tests/                17 automated tests
│   ├── requirements.txt
│   └── .env.example
```

## What you need

- **Python 3.10 or newer** (python.org)
- **PostgreSQL 13 or newer** (postgresql.org/download). The installer also gives you **pgAdmin**. Remember the password you set for the `postgres` user.
- **VS Code**

## Run it (Windows, step by step)

**1. Create the database.** Open **pgAdmin**, connect to your server, right-click *Databases*, choose *Query Tool*, paste the content of `backend/sql/setup_database.sql` and run it (F5). This creates the database `krishiconnect` and the user `krishi`. (Change the password in that file if you like, and use the same one in step 3.)

**2. Open the project in VS Code.** File, Open Folder, choose the `krishiconnect` folder. Open a terminal with Ctrl + `.

**3. Install and configure the backend.**

```powershell
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

If PowerShell says scripts are disabled, run `Set-ExecutionPolicy -Scope Process Bypass` and activate again.

Open `backend\.env` and set:
- `DATABASE_URL` to match your database user and password
- `JWT_SECRET` to a long random value. Generate one with:
  `python -c "import secrets; print(secrets.token_urlsafe(48))"`

**4. Start the server.**

```powershell
uvicorn app.main:app --reload
```

The tables are created automatically on the first start.

**5. Open the app:** <http://127.0.0.1:8000>. Register an account, and you land on the dashboard. API documentation with a try-it-out screen is at <http://127.0.0.1:8000/docs>.

(You can also open `frontend/index.html` with the Live Server extension on port 5500. It calls the API on port 8000, so keep the server running.)

## See the data in PostgreSQL

In pgAdmin: *krishiconnect, Schemas, public, Tables, users* (right-click, View/Edit Data). Or run this query:

```sql
SELECT name, email, phone, role, preferred_language, created_at FROM users ORDER BY created_at DESC;
```

You will see that `password_hash` holds a long bcrypt hash, never the real password.

## Create an admin

Nobody can become an admin from the public form (the server refuses it). Create one from the terminal:

```powershell
python -m app.create_admin
```

Then log in on the page with the **Admin** role card. The admin-only endpoint `GET /api/admin/users` (try it in `/docs`) lists all users.

## API

| Method | URL | Who | What it does |
|---|---|---|---|
| POST | `/api/auth/register` | anyone | Create a farmer, buyer or seller account. Returns a token. |
| POST | `/api/auth/login` | anyone | Log in with email, password and role. Returns a token. |
| GET | `/api/auth/me` | logged in | The current user (used by the dashboard). |
| GET | `/api/admin/users` | admin only | List users. |
| GET | `/api/health` | anyone | Checks that the database is reachable. |

Send the token in the header `Authorization: Bearer <token>`. Errors look like `{"detail": {"code": "...", "message": "..."}}`; the web page turns the `code` into the language chosen by the user.

## Security built in

- Passwords are hashed with **bcrypt** (12 rounds). Minimum 8 characters.
- The login token (JWT) expires after 60 minutes.
- **5 wrong passwords lock the account for 15 minutes.** Unknown email and wrong password give the same answer, so nobody can discover which emails are registered.
- The **Admin role cannot be chosen on the public form**, and role checks happen on the server.
- Every database query uses parameters (no SQL injection). Email and phone are unique inside the database itself.
- The browser may only call the API from the addresses listed in `CORS_ORIGINS`.

For a real deployment also use HTTPS, a strong `JWT_SECRET`, and move the token from browser storage to an HttpOnly cookie.

## Tests

Create an empty test database once (pgAdmin Query Tool): `CREATE DATABASE krishiconnect_test OWNER krishi;`

```powershell
$env:TEST_DATABASE_URL="postgresql://krishi:krishi123@localhost:5432/krishiconnect_test"
pytest -q
```

The tests empty the `users` table of the **test** database each time, so never point `TEST_DATABASE_URL` at your real data.

## Troubleshooting

| Problem | Fix |
|---|---|
| `connection refused` / server will not start | PostgreSQL is not running. Start the *postgresql* service (Windows Services) and check the port (5432) in `DATABASE_URL`. |
| `password authentication failed for user "krishi"` | The password in `.env` differs from the one in `setup_database.sql`. |
| `ModuleNotFoundError: No module named 'app'` | Run uvicorn from inside the `backend` folder. |
| Page says "Cannot reach the server" | The backend is not running. Start step 4 again. |
| Port 8000 already used | `uvicorn app.main:app --reload --port 8001`, then open that port (and add it to `CORS_ORIGINS` if you use Live Server). |
| Everyone is logged out after each restart | `JWT_SECRET` is not set in `.env`. |

## Not built yet

Forgot password, Google sign-in and Mobile OTP buttons are still demo messages (they need an email or SMS service). The dashboard shows the user and placeholder tiles; marketplace, community and price forecasts are the next modules.
